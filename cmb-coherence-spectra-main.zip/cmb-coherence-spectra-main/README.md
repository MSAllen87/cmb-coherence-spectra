# cmb-coherence-spectra
.py to compare predictions to CMB Planck data
